# 🚀 Modularized AIOps Alert Processing Pipeline

A comprehensive, modular AIOps solution for alert processing, deduplication, and Root Cause Analysis (RCA) classification using machine learning and graph analytics.

## 📁 Project Structure

```
aiops/
├── config.py                 # Configuration and constants
├── data_processor.py         #数据加载和处理模块
├── graph_enricher.py        # Graph enrichment and relationships
├── alert_deduplicator.py    # Temporal deduplication
├── ml_classifier.py         # Machine learning and classification
├── visualizer.py           # Visualization and reporting
├── main.py                 # Main orchestrator
├── requirements.txt        # Dependencies
├── example_usage.py       # Usage examples
└── README.md              # This file
```

## 🎯 Key Features

### 📊 **Data Processing**
- **Smart Alert Parsing**: Handles multi-format alert data with robust error handling
- **Temporal Information Extraction**: Automated timestamp parsing and processing
- **Flexible Data Sources**: Support for CSV and JSON data formats

### 🔗 **Graph Enrichment**
- **Service Relationship Mapping**: Complex service dependency analysis  
- **Fuzzy Service Matching**: Intelligent service name matching across data sources
- **Centrality Analysis**: Importance scoring for services in the dependency network
- **Multi-level Relationship Detection**: CALLS, BELONGS_TO, OWNS_TYPE relationships

### 🔄 **Temporal Deduplication**
- **Multi-criteria Matching**: Service, resource type, severity, and description similarity
- **Time Window Optimization**: Configurable deduplication time windows
- **Intelligent Consolidation**: Alert grouping with affected resource tracking
- **Performance Metrics**: Deduplication effectiveness analysis

### 🧠 **Machine Learning Classification**
- **Multi-Algorithm Training**: RandomForest, XGBoost, LightGBM, Neural Networks, SVM
- **Advanced Feature Engineering**: 50+ engineered features across categories
- **Feature Selection**: Multiple selection strategies (univariate, model-based, recursive)
- **Performance Validation**: Cross-validation and comprehensive model comparison

### 🎨 **Comprehensive Visualization**
- **Pipeline Performance Charts**: Process efficiency and volume tracking
- **Feature Importance Analysis**: Visual feature ranking and category breakdown
- **Temporal Pattern Analysis**: Alert distribution and severity patterns over time
- **Service Network Visualization**: Interactive dependency network graphs
- **Executive Dashboard**: Comprehensive summary visualization

## 🚀 Quick Start

### Installation

```bash
pip install -r requirements.txt
```

### Basic Usage

```python
from main import AIOpsPipeline

# Initialize pipeline
pipeline = AIOpsPipeline(
    alerts_csv_path="path/to/your/alerts.csv",
    graph_json_path="path/to/your/graph_data.json"
)

# Run complete pipeline
processor, results = pipeline.run_full_pipeline()
```

### Configuration

Modify `config.py` for custom settings:

```python
# Deduplication time window
DATA_CONFIG['time_window_minutes'] = 10

# ML model settings
ML_CONFIG['models']['RandomForest']['n_estimators'] = 500

# Visualization preferences
VIZ_CONFIG['figure_size'] = (20, 12)
```

## 📈 Pipeline Stages

1. **📥 Data Loading & Processing**: Parse alerts, extract metadata
2. **🔗 Graph Enrichment**: Map service relationships, calculate centrality  
3. **🔄 Temporal Deduplication**: Remove duplicate alerts within time windows
4. **🤝 Relationship Consolidation**: Group related alerts using graph context
5. **🧠 ML Classification**: Train multiple models, select best performer
6. **🎨 Visualization**: Generate comprehensive charts and dashboards
7. **📊 Reporting**: Create actionable insights and recommendations

## 📊 Output Files

The pipeline generates several output files:

- `deduplicated_alerts.csv` - Cleaned alert data after deduplication
- `rca_classified_alerts.csv` - Alert groups with RCA classifications
- `aiops_comprehensive_dashboard.png` - Executive summary dashboard
- `pipeline_performance_overview.png` - Processing pipeline metrics
- `feature_importance_analysis.png` - Feature ranking and analysis
- `temporal_analysis_overview.png` - Time-based alert patterns
- `service_network_visualization.png` - Service dependency network

## 🎛️ Advanced Usage

### Step-by-Step Execution

```python
from main import AIOpsPipeline

pipeline = AIOpsPipeline(alerts_path, graph_path)

# Individual steps
alerts = pipeline.data_processor.load_and_process_alerts()
enriched_alerts = pipeline.graph_enricher.enrich_alerts_with_graph_context(alerts)
deduplicated = pipeline.alert_deduplicator.temporal_deduplication(enriched_alerts)
consolidated = pipeline.alert_deduplicator.consolidate_alerts_by_relationships(deduplicated, pipeline.graph_enricher)
classified = pipeline.ml_classifier.classify_alerts_for_rca(consolidated)
```

### Custom Feature Engineering

```python
# Access feature vectors before classification
features, labels = pipeline.ml_classifier.prepare_advanced_features(consolidated_groups)

# Add custom features
features['custom_feature'] = your_custom_calculation()

# Retrain with custom features
pipeline.ml_classifier.train_advanced_classifier(features, labels)
```

### Performance Monitoring

```python
# Get model performance metrics
perf = pipeline.ml_classifier.model_performance
best_model = max(perf.items(), key=lambda x: x[1]['cv_score'])

# Feature importance analysis
importance = pipeline.ml_classifier.feature_importance
top_features = importance.head(10)
```

## 🔧 Configuration Options

### Data Processing
- `time_window_minutes`: Deduplication time window (default: 5)
- `description_similarity_threshold`: Text similarity threshold (default: 0.85)
- `temporal_window_minutes`: Relationship grouping window (default: 30)

### Machine Learning
- `test_size`: Test set proportion (default: 0.2)
- `cv_sparse`: Cross-validation folds (default: 5)
- `feature_selection_methods`: Multiple selection strategies
- `model_hyperparameters`: Per-algorithm tuning parameters

### Visualization  
- `figure_size`: Chart dimensions (default: 24x16)
- `dpi`: Output resolution (default: 300)
- `color_schemes`: Consistent color palettes
- `save_formats`: Supported image formats

## 📋 Requirements

- Python 3.8+
- pandas >= 1.3.0
- numpy >= 1.21.0
- scikit-learn >= 1.0.0
- matplotlib >= 3.5.0
- seaborn >= 0.11.0
- networkx >= 2.6
- xgboost >= 1.5.0 (optional)
- lightgbm >= 3.3.0 (optional)

## 🎯 RCA Categories

The pipeline classifies alerts into these RCA categories:

- `infrastructure_wide_failure` - Large-scale infrastructure issues
- `cascading_service_failure` - Service dependency chain failures
- `resource_exhaustion_critical_service` - Critical service resource exhaustion
- `memory_leak_or_pressure` - Memory-related problems
- `distributed_service_issue` - Multi-service coordination problems
- `correlated_incidents` - Temporally correlated but unrelated issues
- `storage_issue` - Storage and disk-related problems
- `network_performance_issue` - Network connectivity/performance
- `critical_service_degradation` - Important service performance decline
- `isolated_service_issue` - Single-service problems

## 🚨 Error Handling

The pipeline includes comprehensive error handling:

- **Data Loading**: Graceful handling of malformed data
- **ML Training**: Fallback models if specific algorithms fail
- **Feature Selection**: Robust selection even with limited data
- **Visualization**: Continue processing if charts fail
- **Memory Management**: Efficient processing of large datasets

## 📊 Performance Benchmarks

Typical processing performance:

- **10K alerts**: ~15-20 seconds total
- **100K alerts**: ~2-3 minutes total  
- **Memory usage**: ~2-4GB for large datasets
- **CPU**: Multi-core utilization for model training

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Update documentation
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For questions or issues:

1. Check the documentation and examples
2. Review the error logs for debugging info
3. Create an issue with sample data and error details

---

**Built with ❤️ for the AIOps community**
