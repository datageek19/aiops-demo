"""
Main orchestrator module for AIOps Alert Processing Pipeline
"""

from typing import Dict, Any, List, Tuple
import warnings

warnings.filterwarnings('ignore')

from data_processor import DataProcessor
from graph_enricher import GraphEnricher  
from alert_deduplicator import AlertDeduplicator
from ml_classifier import MLClassifier
from visualizer import Visualizer
from config import DATA_CONFIG


class AIOpsPipeline:
    """
    Main orchestrator for the AIOps Alert Processing Pipeline
    """
    
    def __init__(self, alerts_csv_path: str, graph_json_path: str):
        self.alerts_csv_path = alerts_csv_path
        self.graph_json_path = graph_json_path
        
        # Initialize modules
        self.data_processor = DataProcessor(alerts_csv_path, graph_json_path)
        self.graph_enricher = GraphEnricher()
        self.alert_deduplicator = AlertDeduplicator()
        self.ml_classifier = MLClassifier()
        self.visualizer = Visualizer()
        
        # Data containers
        self.firing_alerts: List[Dict[str, Any]] = []
        self.enriched_alerts: List[Dict[str, Any]] = []
        self.deduplicated_alerts: List[Dict[str, Any]] = []
        self.consolidated_groups: List[Dict[str, Any]] = []
        self.classified_alerts: List[Dict[str, Any]] = []
        
        # Processing results
        self.results: Dict[str, Any] = {}
        self.processor_data: Dict[str, Any] = {}
    
    def run_full_pipeline(self) -> Tuple[Any, Dict[str, Any]]:
        """Execute the complete AIOps pipeline"""
        print("="*70)
        print("COMPREHENSIVE AIOPS ALERT PROCESSING & RCA CLASSIFICATION")
        print("="*70)
        
        try:
            # Step 1: Load and process alerts
            self._load_and_process_alerts()
            
            # Step 2: Enrich with graph context
            self._enrich_with_graph_context()
            
            # Step 3: Temporal deduplication
            self._perform_temporal_deduplication()
            
            # Step 4: Consolidate by relationships
            self._consolidate_by_relationships()
            
            # Step 5: Advanced RCA classification
            self._perform_ml_classification()
            
            # Step 6: Generate visualizations
            self._generate_visualizations()
            
            # Step 7: Generate comprehensive report
            self.results = self._generate_comprehensive_report()
            
            # Step 8: Save results
            self._save_all_results()
            
            print(f"\n🎉 PIPELINE COMPLETED SUCCESSFULLY!")
            return self, self.results
            
        except Exception as e:
            print(f"Pipeline error: {e}")
            import traceback
            traceback.print_exc()
            return None, {}
    
    def _load_and_process_alerts(self) -> None:
        """Step 1: Load and process raw alert data"""
        print("\n📥 STEP 1: Loading and Processing Alerts")
        print("-" * 50)
        
        self.firing_alerts = self.data_processor.load_and_process_alerts()
        graph_data = self.data_processor.load_graph_data()
        
        # Store graph data for subsequent steps
        self.graph_data = graph_data
        
        print(f"✅ Loaded {len(self.firing_alerts)} firing alerts")
        print(f"✅ Loaded {len(graph_data)} graph relationships")
    
    def _enrich_with_graph_context(self) -> None:
        """Step 2: Enrich alerts with graph context"""
        print("\n🔗 STEP 2: Enriching with Graph Context")
        print("-" * 50)
        
        # Build service graph
        service_mappings = self.graph_enricher.build_service_graph(self.graph_data)
        
        # Enrich alerts
        self.enriched_alerts = self.graph_enricher.enrich_alerts_with_graph_context(self.firing_alerts)
        
        # Store enrichment statistics
        enriched_count = len([a for a in self.enriched_alerts if a.get('has_graph_context')])
        exact_matches = len([a for a in self.enriched_alerts if a.get('match_type') == 'exact'])
        fuzzy_matches = len([a for a in self.enriched_alerts if a.get('match_type') == 'fuzzy'])
        
        print(f"✅ Enriched {enriched_count}/{len(self.firing_alerts)} alerts with graph context")
        print(f"✅ Exact matches: {exact_matches}, Fuzzy matches: {fuzzy_matches}")
    
    def _perform_temporal_deduplication(self) -> None:
        """Step 3: Perform temporal deduplication"""
        print("\n🔄 STEP 3: Temporal Deduplication")
        print("-" * 50)
        
        self.deduplicated_alerts, duplicate_groups = self.alert_deduplicator.temporal_deduplication(
            self.enriched_alerts, 
            DATA_CONFIG['time_window_minutes']
        )
        
        reduction = len(self.enriched_alerts) - len(self.deduplicated_alerts)
        reduction_pct = (reduction / len(self.enriched_alerts) * 100) if len(self.enriched_alerts) > 0 else 0
        
        print(f"✅ Deduplicated {len(self.enriched_alerts)} → {len(self.deduplicated_alerts)} alerts")
        print(f"✅ Removed {reduction} duplicates ({reduction_pct:.1f}% reduction)")
        print(f"✅ Created {len(duplicate_groups)} duplicate groups")
    
    def _consolidate_by_relationships(self) -> None:
        """Step 4: Consolidate alerts by graph relationships"""
        print("\n🤝 STEP 4: Consolidation by Graph Relationships")
        print("-" * 50)
        
        self.consolidated_groups = self.alert_deduplicator.consolidate_alerts_by_relationships(
            self.deduplicated_alerts,
            self.graph_enricher
        )
        
        multi_alert_groups = [g for g in self.consolidated_groups if g['total_alerts'] > 1]
        
        print(f"✅ Created {len(self.consolidated_groups)} consolidated groups")
        print(f"✅ Multi-alert groups: {len(multi_alert_groups)}")
        print(f"✅ Isolated alerts: {len(self.consolidated_groups) - len(multi_alert_groups)}")
    
    def _perform_ml_classification(self) -> None:
        """Step 5: Advanced ML-based RCA classification"""
        print("\n🧠 STEP 5: Advanced RCA Classification")
        print("-" * 50)
        
        # Train advanced classifier
        self.ml_classifier.train_advanced_classifier(self.consolidated_groups)
        
        # Classify alerts
        self.classified_alerts = self.ml_classifier.classify_alerts_for_rca(self.consolidated_groups)
        
        # Generate model comparison report
        self.ml_classifier.generate_model_comparison_report()
        
        print(f"✅ Trained {len(self.ml_classifier.models)} ML models")
        print(f"✅ Best model: {self.ml_classifier.best_model}")
        print(f"✅ Selected {len(self.ml_classifier.best_features)} features")
        print(f"✅ Classified {len(self.classified_alerts)} alert groups")
    
    def _generate_visualizations(self) -> None:
        """Step 6: Generate comprehensive visualizations"""
        print("\n🎨 STEP 6: Generating Comprehensive Visualizations")
        print("-" * 50)
        
        # Prepare processor data for visualizations
        self._prepare_processor_data_for_visualizations()
        
        try:
            # Create individual visualization charts
            self.visualizer.create_pipeline_performance_chart(self.processor_data)
            
            if self.ml_classifier.feature_importance is not None:
                self.visualizer.create_feature_importance_chart(self.ml_classifier.feature_importance)
            
            # Create temporal analysis
            alerts_with_time = [a for a in self.enriched_alerts if a.get('start_datetime')]
            self.visualizer.create_temporal_analysis_chart(alerts_with_time)
            
            # Create service network visualization
            self.visualizer.create_service_network_visualization(self.graph_enricher.service_graph)
            
            # Create comprehensive dashboard
            self.visualizer.create_comprehensive_dashboard(
                self.processor_data, 
                self.classified_alerts,
                alerts_with_time,
                self.graph_enricher.service_graph
            )
            
            print("✅ All visualizations generated successfully")
            
        except Exception as e:
            print(f"⚠️ Visualization error: {e}")
            print("Continuing with results generation...")
    
    def _prepare_processor_data_for_visualizations(self) -> None:
        """Prepare processor data for visualization modules"""
        self.processor_data = {
            'original_count': len(self.firing_alerts),
            'enriched_count': len([a for a in self.enriched_alerts if a.get('has_graph_context')]),
            'deduplicated_count': len(self.deduplicated_alerts),
            'consolidated_count': len(self.consolidated_alerts),
            'exact_matches': len([a for a in self.enriched_alerts if a.get('match_type') == 'exact']),
            'fuzzy_matches': len([a for a in self.enriched_alerts if a.get('match_type') == 'fuzzy']),
            'best_model': self.ml_classifier.best_model,
            'best_features': self.ml_classifier.best_features,
            'models': self.ml_classifier.models,
            'model_performance': self.ml_classifier.model_performance,
            'feature_importance': self.ml_classifier.feature_importance,
            'high_priority_groups': 0,
            'cascading_failures': 0,
            'avg_confidence': 0.0,
            'rca_categories': {}
        }
        
        # Calculate additional metrics
        if self.classified_alerts:
            high_priority = [g for g in self.classified_alerts if g['total_alerts'] > 2]
            self.processor_data['high_priority_groups'] = len(high_priority)
            
            cascading_failures = [g for g in self.classified_alerts if 'cascading' in g['final_rca_category']]
            self.processor_data['cascading_failures'] = len(cascading_failures)
            
            if self.classified_alerts:
                avg_confidence = sum(g.get('ml_confidence', 0) for g in self.classified_alerts) / len(self.classified_alerts)
                self.processor_data['avg_confidence'] = avg_confidence
            
            rca_categories = Counter(g['final_rca_category'] for g in self.classified_alerts)
            self.processor_data['rca_categories'] = dict(rca_categories)
    
    def _generate_comprehensive_report(self) -> Dict[str, Any]:
        """Step 7: Generate comprehensive report"""
        print("\n📊 STEP 7: Generating Comprehensive Report")
        print("-" * 50)
        
        return self.visualizer.generate_comprehensive_report(self.processor_data, self.classified_alerts)
    
    def _save_all_results(self) -> None:
        """Step 8: Save all processing results"""
        print("\n💾 STEP 8: Saving All Results")
        print("-" * 50)
        
        self.visualizer.save_results(self.deduplicated_alerts, self.classified_alerts)
    
    def get_summary(self) -> Dict[str, Any]:
        """Get pipeline execution summary"""
        return {
            'original_alerts': len(self.firing_alerts),
            'enriched_alerts': len(self.enriched_alerts),
            'deduplicated_alerts': len(self.deduplicated_alerts),
            'consolidated_groups': len(self.consolidated_groups),
            'classified_alerts': len(self.classified_alerts),
            'best_model': self.ml_classifier.best_model if hasattr(self.ml_classifier, 'best_model') else 'N/A',
            'models_trained': len(self.ml_classifier.models) if hasattr(self.ml_classifier, 'models') else 0,
            'features_selected': len(self.ml_classifier.best_features) if hasattr(self.ml_classifier, 'best_features') else 0
        }


def main():
    """Main execution function with error handling"""
    
    # Configuration - Update paths as needed
    alerts_csv_path = 'alert_data.csv'
    graph_json_path = 'graph_data.json'
    
    print("🚀 Starting AIOps Alert Processing Pipeline...")
    print(f"📁 Alert Data: {alerts_csv_path}")
    print(f"📁 Graph Data: {graph_json_path}")
    
    # Initialize and run pipeline
    pipeline = AIOpsPipeline(alerts_csv_path, graph_json_path)
    
    try:
        processor, results = pipeline.run_full_pipeline()
        
        if processor:
            summary = processor.get_summary()
            print(f"\n📈 FINAL SUMMARY:")
            print(f"   Original Alerts: {summary['original_alerts']}")
            print(f"   Final Alert Groups: {summary['classified_alerts']}")
            print(f"   Best Model: {summary['best_model']}")
            print(f"   Models Trained: {summary['models_trained']}")
            
            return processor, results
        else:
            print("❌ Pipeline execution failed")
            return None, {}
            
    except Exception as e:
        print(f"❌ Critical error in main execution: {e}")
        import traceback
        traceback.print_exc()
        return None, {}


if __name__ == "__main__":
    processor, results = main()
