"""
Graph enrichment and relationship processing module
"""

import networkx as nx
import difflib
from typing import List, Dict, Any, Set, Tuple
import numpy as np
from collections import Counter


class GraphEnricher:
    """
    Handles graph context enrichment for alerts
    """
    
    def __init__(self):
        self.service_graph = nx.DiGraph()
        self.service_to_graph = {}
        
    def build_service_graph(self, graph_relationships: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Build service graph and mappings from relationships"""
        print("Building service graph...")
        
        for rel in graph_relationships:
            source_props = rel.get('source_properties') or {}
            target_props = rel.get('target_properties') or {}
            
            source_service_name = source_props.get('name', '')
            target_service_name = target_props.get('name', '')
            
            # Map source service
            if source_service_name:
                self.service_to_graph[source_service_name] = {
                    'graph_name': rel.get('source_name', ''),
                    'properties': source_props,
                    'type': rel.get('source_label', ''),
                    'environment': source_props.get('environment', ''),
                    'namespace': source_props.get('namespace', ''),
                    'cluster': source_props.get('cluster', '')
                }
                self.service_graph.add_node(source_service_name, **source_props)
            
            # Map target service
            if target_service_name:
                self.service_to_graph[target_service_name] = {
                    'graph_name': rel.get('target_name', ''),
                    'properties': target_props,
                    'type': rel.get('target_label', ''),
                    'environment': target_props.get('environment', ''),
                    'namespace': target_props.get('namespace', ''),
                    'cluster': target_props.get('cluster', '')
                }
                self.service_graph.add_node(target_service_name, **target_props)
            
            # Add relationship edge
            rel_type = rel.get('relationship_type', '')
            if source_service_name and target_service_name and rel_type:
                self.service_graph.add_edge(
                    source_service_name,
                    target_service_name,
                    relationship_type=rel_type
                )
        
        print(f"Built service graph with {len(self.service_to_graph)} services")
        return self.service_to_graph
    
    def enrich_alerts_with_graph_context(self, alerts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Enrich alerts with graph relationship context"""
        print("Enriching alerts with graph context...")
        
        enriched_count = 0
        fuzzy_matches = 0
        
        for alert in alerts:
            service_name = str(alert.get('service_name') or '').strip()
            alert['has_graph_context'] = False
            alert['calls_services'] = []
            alert['called_by_services'] = []
            alert['belongs_to_services'] = []
            alert['owns_services'] = []
            alert['service_centrality'] = 0.0
            alert['matched_graph_service'] = service_name
            
            # Direct match first
            if service_name in self.service_to_graph:
                matched_service = service_name
                alert['match_type'] = 'exact'
            else:
                # Fuzzy matching fallback
                matched_service = self._find_fuzzy_service_match(service_name)
                if matched_service:
                    fuzzy_matches += 1
                    alert['matched_graph_service'] = matched_service
                    alert['match_type'] = 'fuzzy'
                else:
                    continue
            
            if matched_service in self.service_to_graph:
                graph_info = self.service_to_graph[matched_service]
                alert['has_graph_context'] = True
                alert['graph_type'] = graph_info['type']
                alert['graph_environment'] = graph_info['environment']
                alert['graph_namespace'] = graph_info['namespace']
                alert['graph_cluster'] = graph_info['cluster']
                
                # Calculate centrality
                try:
                    centrality = nx.degree_centrality(self.service_graph)[matched_service]
                    alert['service_centrality'] = centrality
                except:
                    alert['service_centrality'] = 0.0
                
                # Find relationship connections
                self._extract_service_relationships(alert, matched_service)
                enriched_count += 1
        
        print(f"Enriched {enriched_count}/{len(alerts)} alerts with graph context")
        print(f"Fuzzy matches used: {fuzzy_matches}")
        return alerts
    
    def _find_fuzzy_service_match(self, alert_service_name: str) -> str:
        """Find best fuzzy match for service name"""
        if not alert_service_name:
            return None
        
        best_match = None
        best_score = 0.0
        
        for graph_service_name in self.service_to_graph.keys():
            score = 0.0
            
            # Strategy 1: Direct substring match
            if alert_service_name.lower() in graph_service_name.lower():
                score = 0.8
            elif graph_service_name.lower() in alert_service_name.lower():
                score = 0.7
            
            # Strategy 2: Similarity scoring
            similarity = difflib.SequenceMatcher(None, alert_service_name.lower(), graph_service_name.lower()).ratio()
            score = max(score, similarity * 0.6)
            
            # Strategy 3: Kubernetes naming patterns
            if 'aks-' in alert_service_name and 'aks-' in graph_service_name:
                alert_parts = alert_service_name.split('-')[1:3] if len(alert_service_name.split('-')) >= 3 else []
                graph_parts = graph_service_name.split('-')[1:3] if len(graph_service_name.split('-')) >= 3 else []
                if alert_parts and graph_parts:
                    alert_key = '-'.join(alert_parts)
                    graph_key = '-'.join(graph_parts)
                    if alert_key == graph_key:
                        score = 0.9


            
            if score > best_score and score > 0.5:  # Minimum threshold
                best_score = score
                best_match = graph_service_name
        
        return best_match
    
    def _extract_service_relationships(self, alert: Dict[str, Any], matched_service: str) -> None:
        """Extract service relationships from graph"""
        for successor in self.service_graph.successors(matched_service):
            edge_data = self.service_graph.get_edge_data(matched_service, successor)
            if edge_data:
                rel_type = edge_data.get('relationship_type')
                if rel_type == 'CALLS':
                    alert['calls_services'].append(successor)
                elif rel_type == 'BELONGS_TO':
                    alert['belongs_to_services'].append(successor)
        
        for predecessor in self.service_graph.predecessors(matched_service):
            edge_data = self.service_graph.get_edge_data(predecessor, matched_service)
            if edge_data:
                rel_type = edge_data.get('relationship_type')
                if rel_type == 'CALLS':
                    alert['called_by_services'].append(predecessor)
                elif rel_type == 'BELONGS_TO':
                    alert['owns_services'].append(predecessor)
    
    def find_relationship_groups(self, primary_alert: Dict[str, Any], all_alerts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Find alerts related through graph relationships"""
        service_name = str(primary_alert.get('service_name') or '').strip()
        related_alerts = [primary_alert]


        
        if not primary_alert.get('has_graph_context'):
            return related_alerts
        
        # Get related services
        related_services = set()
        related_services.update(primary_alert.get('calls_services', []))
        related_services.update(primary_alert.get('called_by_services', []))
        related_services.update(primary_alert.get('belongs_to_services', []))
        related_services.update(primary_alert.get('owns_services', []))
        
        # Find alerts for related services
        for alert in all_alerts:
            if (alert.get('_id') != primary_alert.get('_id') and 
                str(alert.get('service_name', '')).strip() in related_services):
                
                # Check temporal proximity (within 30 minutes for relationship grouping)
                if (primary_alert.get('start_datetime') and alert.get('start_datetime')):
                    time_diff = abs((alert['start_datetime'] - primary_alert['start_datetime']).total_seconds() / 60)
                    if time_diff <= 30:  # 30-minute window for relationship grouping
                        related_alerts.append(alert)
        
        return related_alerts
    
    def determine_group_relationship_type(self, alerts: List[Dict[str, Any]]) -> str:
        """Determine the primary relationship type for a group"""
        if len(alerts) <= 1:
            return 'isolated'
        
        primary_alert = alerts[0]
        
        # Check if it's a service dependency chain
        calls_services = primary_alert.get('calls_services', [])
        called_by_services = primary_alert.get('called_by_services', [])
        
        related_service_names = [a.get('service_name') for a in alerts[1:]]
        
        if any(service in calls_services for service in related_service_names):
            return 'service_dependency_downstream'
        elif any(service in called_by_services for service in related_service_names):
            return 'service_dependency_upstream'
        elif any(service in primary_alert.get('belongs_to_services', []) for service in related_service_names):
            return 'ownership_relationship'
        else:
            return 'infrastructure_related'
    
    def predict_rca_category(self, alerts: List[Dict[str, Any]]) -> str:
        """Predict RCA category based on alert characteristics and relationships"""
        if not alerts:
            return 'unknown'
        
        primary_alert = alerts[0]
        
        # Analyze resource types
        resource_types = [a.get('anomaly_resource_type', '') for a in alerts]
        resource_counter = Counter(resource_types)
        dominant_resource = resource_counter.most_common(1)[0][0] if resource_counter else ''
        
        # Analyze service centrality
        avg_centrality = np.mean([a.get('service_centrality', 0) for a in alerts])
        
        # Analyze relationship patterns
        has_dependencies = any(a.get('calls_services') or a.get('called_by_services') for a in alerts)
        
        # Enhanced rule-based RCA prediction
        if len(alerts) > 5 and ('network' in dominant_resource or 'disk' in dominant_resource):
            return 'infrastructure_wide_failure'
        elif len(alerts) > 2 and has_dependencies:
            return 'cascading_service_failure'
        elif ('cpu' in dominant_resource or 'memory' in dominant_resource) and avg_centrality > 0.1:
            return 'resource_exhaustion_critical_service'
        elif 'memory' in dominant_resource and len(alerts) > 1:
            return 'memory_leak_or_pressure'
        elif len(alerts) > 1:
            # Multi-alert events suggest systemic issues
            if avg_centrality > 0.05:
                return 'distributed_service_issue'
            else:
                return 'correlated_incidents'
        elif 'disk' in dominant_resource or 'storage' in dominant_resource:
            return 'storage_issue'
        elif 'network' in dominant_resource or 'traffic' in dominant_resource:
            return 'network_performance_issue'
        elif avg_centrality > 0.2:
            return 'critical_service_degradation'
        else:
            return 'isolated_service_issue'
