"""
Example usage of the modularized AIOps Alert Processing Pipeline
"""

from main import AIOpsPipeline


def example_basic_usage():
    """Basic usage example"""
    print("📚 AIOps Pipeline - Basic Usage Example")
    print("=" * 50)
    
    # Define your data paths
    alerts_csv_path = "path/to/your/alert_data.csv"
    graph_json_path = "path/to/your/graph_data.json"
    
    # Initialize pipeline
    pipeline = AIOpsPipeline(alerts_csv_path, graph_json_path)
    
    # Run the complete pipeline
    processor, results = pipeline.run_full_pipeline()
    
    if processor:
        # Get summary statistics
        summary = processor.get_summary()
        
        print(f"\n✅ Pipeline completed successfully!")
        print(f"📊 Summary:")
        print(f"   • Original alerts processed: {summary['original_alerts']}")
        print(f"   • Final alert groups: {summary['classified_alerts']}")
        print(f"   • Best ML model: {summary['best_model']}")
        print(f"   • Models trained: {summary['models_trained']}")
        print(f"   • Features used: {summary['features_selected']}")
        
        # Access results
        print(f"\n📋 Results available:")
        print(f"   • deduplicated_alerts.csv")
        print(f"   • rca_classified_alerts.csv")
        print(f"   • aiops_comprehensive_dashboard.png")
        print(f"   • pipeline_performance_overview.png")
        print(f"   • feature_importance_analysis.png")
        print(f"   • temporal_analysis_overview.png")
        print(f"   • service_network_visualization.png")
    
    return processor, results


def example_advanced_usage():
    """Advanced usage example with custom configuration"""
    print("🚀 AIOps Pipeline - Advanced Usage Example")
    print("=" * 50)
    
    # Custom configuration
    from config import DATA_CONFIG
    DATA_CONFIG['time_window_minutes'] = 10  # Custom deduplication window
    
    # Initialize pipeline
    alerts_csv_path = "path/to/your/alert_data.csv"
    graph_json_path = "path/to/your/graph_data.json"
    
    pipeline = AIOpsPipeline(alerts_csv_path, graph_json_path)
    
    try:
        # Run with error handling
        processor, results = pipeline.run_full_pipeline()
        
        if processor:
            # Access individual components for detailed analysis
            high_priority_alerts = [
                group for group in processor.classified_alerts 
                if group.get('total_alerts', 0) > 3
            ]
            
            print(f"🚨 Found {len(high_priority_alerts)} high-priority alert groups")
            
            # Analyze model performance
            if processor.ml_classifier.model_performance:
                best_model = max(
                    processor.ml_classifier.model_performance.items(),
                    key=lambda x: x[1]['cv_score']
                )
                print(f"🏆 Best model performance: {best_model[0]} ({best_model[1]['cv_score']:.3f})")
            
            # Feature importance analysis
            if processor.ml_classifier.feature_importance is not None:
                top_features = processor.ml_classifier.feature_importance.head(3)
                print(f"🔍 Top important features:")
                for _, row in top_features.iterrows():
                    print(f"   • {row['feature']}: {row['avg_importance']:.3f}")
        
        return processor, results
        
    except Exception as e:
        print(f"❌ Error in advanced usage: {e}")
        return None, {}


def example_step_by_step():
    """Step-by-step execution example"""
    print("⚙️ AIOps Pipeline - Step-by-Step Example")
    print("=" * 50)
    
    # Initialize pipeline components
    alerts_csv_path = "path/to/your/alert_data.csv"
    graph_json_path = "path/to/your/graph_data.json"
    
    pipeline = AIOpsPipeline(alerts_csv_path, graph_json_path)
    
    try:
        # Step 1: Load data
        print("📥 Step 1: Loading data...")
        alerts = pipeline.data_processor.load_and_process_alerts()
        graph_data = pipeline.data_processor.load_graph_data()
        print(f"   ✅ Loaded {len(alerts)} alerts and {len(graph_data)} relationships")
        
        # Step 2: Enrich with graph context
        print("🔗 Step 2: Enriching with graph context...")
        service_mappings = pipeline.graph_enricher.build_service_graph(graph_data)
        enriched_alerts = pipeline.graph_enricher.enrich_alerts_with_graph_context(alerts)
        enriched_count = len([a for a in enriched_alerts if a.get('has_graph_context')])
        print(f"   ✅ Enriched {enriched_count}/{len(alerts)} alerts")
        
        # Step 3: Deduplication
        print("🔄 Step 3: Deduplicating alerts...")
        deduplicated_alerts, duplicate_groups = pipeline.alert_deduplicator.temporal_deduplication(enriched_alerts)
        print(f"   ✅ Deduplicated {len(alerts)} → {len(deduplicated_alerts)} alerts")
        
        # Step 4: Consolidation
        print("🤝 Step 4: Consolidating by relationships...")
        consolidated_groups = pipeline.alert_deduplicator.consolidate_alerts_by_relationships(
            deduplicated_alerts, pipeline.graph_enricher)
        print(f"   ✅ Created {len(consolidated_groups)} consolidated groups")
        
        # Step 5: ML Classification
        print("🧠 Step 5: ML classification...")
        pipeline.ml_classifier.train_advanced_classifier(consolidated_groups)
        classified_alerts = pipeline.ml_classifier.classify_alerts_for_rca(consolidated_groups)
        print(f"   ✅ Classified {len(classified_alerts)} groups using {pipeline.ml_classifier.best_model}")
        
        # Step 6: Visualizations
        print("🎨 Step 6: Generating visualizations...")
        # ... visualization code would go here ...
        print("   ✅ Generated visualizations")
        
        print(f"\n🎉 Step-by-step execution completed successfully!")
        return pipeline.classified_alerts
        
    except Exception as e:
        print(f"❌ Error in step-by-step execution: {e}")
        return []


if __name__ == "__main__":
    print("🚀 AIOps Alert Processing Pipeline - Usage Examples")
    print("=" * 60)
    
    # Uncomment the example you want to run:
    
    # Basic usage
    # processor, results = example_basic_usage()
    
    # Advanced usage  
    # processor, results = example_advanced_usage()
    
    # Step-by-step execution
    # classified_alerts = example_step_by_step()
    
    print("\n💡 Note: Update file paths in the code before running!")
    print("\n📖 The modularized pipeline includes:")
    print("   • config.py - Configuration and constants")
    print("   • data_processor.py - Data loading and parsing")
    print("   • graph_enricher.py - Graph enrichment and relationships")
    print("   • alert_deduplicator.py - Temporal deduplication")
    print("   • ml_classifier.py - ML training and classification")
    print("   • visualizer.py - Visualization and reporting")
    print("   • main.py - Main orchestrator")
    print("   • requirements.txt - Dependencies")
