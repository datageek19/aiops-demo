"""
Visualization and reporting module for AIOps Alert Pipeline
"""

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from typing import List, Dict, Any
import networkx as nx
from collections import Counter
from config import VIZ_CONFIG, FEATURE_CATEGORIES

# Visualization configuration
plt.style.use('default')
sns.set_palette("husl")


class Visualizer:
    """
    Handles visualization and reporting for AIOps pipeline
    """
    
    def __init__(self):
        self.figure_size = VIZ_CONFIG['figure_size']
        self.dpi = VIZ_CONFIG['dpi']
        self.colors = VIZ_CONFIG['colors']
        self.metrics_colors = VIZ_CONFIG['metrics_colors']
        
    def create_pipeline_performance_chart(self, processor_data: Dict[str, Any]) -> plt.Figure:
        """Create pipeline performance visualization"""
        print("Generating pipeline performance charts...")
        
        # Prepare data for visualization
        stages = ['Original\nAlerts', 'Graph\nEnriched', 'After\nDeduplication', 'Consolidated\nGroups']
        counts = [
            processor_data['original_count'],
            processor_data['enriched_count'], 
            processor_data['deduplicated_count'],
            processor_data['consolidated_count']
        ]
        
        # Create figure with subplots
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('🔄 AIOps Alert Processing Pipeline Performance', fontsize=16, fontweight='bold')
        
        # 1. Pipeline Flow Chart
        bars = ax1.bar(stages, counts, color=self.colors, alpha=0.8, edgecolor='black', linewidth=1)
        ax1.set_title('📊 Alert Volume Through Pipeline Stages', fontsize=14, fontweight='bold')
        ax1.set_ylabel('Number of Alerts/Groups')
        
        # Add value labels on bars
        for bar, count in zip(bars, counts):
            height = bar.get_height()
            ax1.text(bar.get_x() + bar.get_width()/2., height + 5,
                    f'{count}', ha='center', va='bottom', fontweight='bold')
        
        # 2. Processing Efficiency Chart
        original_count = processor_data['original_count']
        enriched_count = processor_data['enriched_count']
        deduplicated_count = processor_data['deduplicated_count']
        
        enrichment_rate = (enriched_count / original_count) * 100
        deduplication_rate = ((original_count - deduplicated_count) / original_count) * 100
        
        categories = ['Graph\nEnrichment', 'Deduplication\nReduction']
        rates = [enrichment_rate, deduplication_rate]
        
        bars2 = ax2.bar(categories, rates, color=self.metrics_colors, alpha=0.8)
        ax2.set_title('⚡ Processing Efficiency Metrics', fontsize=14, fontweight='bold')
        ax2.set_ylabel('Percentage (%)')
        ax2.set_ylim(0, max(rates) * 1.2)
        
        for bar, rate in zip(bars2, rates):
            height = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width()/2., height + 1,
                    f'{rate:.1f}%', ha='center', va='bottom', fontweight='bold')
        
        # 3. RCA Category Distribution (Pie Chart)
        rca_categories = processor_data.get('rca_categories', {})
        if rca_categories:
            labels = list(rca_categories.keys())
            sizes = list(rca_categories.values())
            
            # Truncate long labels
            labels_short = [label.replace('_', ' ').title()[:15] for label in labels]
            
            wedges, texts, autotexts = ax3.pie(sizes, labels=labels_short, autopct='%1.1f%%',
                                              startangle=90, colors=plt.cm.Set3.colors)
            ax3.set_title('🎯 RCA Classification Distribution', fontsize=14, fontweight='bold')
            
            # Make percentage text bold
            for autotext in autotexts:
                autotext.set_color('white')
                autotext.set_fontweight('bold')
        
        # 4. Model Performance Comparison
        model_performance = processor_data.get('model_performance', {})
        if model_performance:
            models = list(model_performance.keys())
            cv_scores = [model_performance[model]['cv_score'] * 100 for model in models]
            
            bars3 = ax4.barh(models, cv_scores, color=plt.cm.viridis(np.linspace(0, 1, len(models))))
            ax4.set_title('🏆 Model Performance (CV Score)', fontsize=14, fontweight='bold')
            ax4.set_xlabel('Cross-Validation Accuracy (%)')
            
            # Highlight best model
            best_model = processor_data.get('best_model')
            if best_model and best_model in models:
                best_idx = models.index(best_model)
                bars3[best_idx].set_color('#FFD700')  # Gold color for best
                bars3[best_idx].set_edgecolor('red')
                bars3[best_idx].set_linewidth(3)
            
            # Add value labels
            for bar, score in zip(bars3, cv_scores):
                width = bar.get_width()
                ax4.text(width + 0.5, bar.get_y() + bar.get_height()/2.,
                        f'{score:.1f}%', ha='left', va='center', fontweight='bold')
        else:
            ax4.text(0.5, 0.5, 'Model Performance\nData Not Available', 
                    ha='center', va='center', transform=ax4.transAxes, fontsize=12)
            ax4.set_title('🏆 Model Performance', fontsize=14, fontweight='bold')
        
        plt.tight_layout()
        plt.savefig('pipeline_performance_overview.png', dpi=self.dpi, bbox_inches='tight')
        plt.show()
        return fig
    
    def create_feature_importance_chart(self, feature_importance: pd.DataFrame) -> plt.Figure:
        """Create feature importance visualization"""
        if feature_importance is None or len(feature_importance) == 0:
            print("No feature importance data available for visualization")
            return None
            
        print("Generating feature importance charts...")
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 10))
        fig.suptitle('🧠 Feature Importance Analysis', fontsize=16, fontweight='bold')
        
        # 1. Top Features Bar Chart
        top_features = feature_importance.head(15)
        
        bars = ax1.barh(range(len(top_features)), top_features['avg_importance'], 
                       color=plt.cm.plasma(np.linspace(0, 1, len(top_features))))
        ax1.set_yticks(range(len(top_features)))
        ax1.set_yticklabels([f.replace('_', ' ').title() for f in top_features['feature']], fontsize=10)
        ax1.set_xlabel('Average Importance Score')
        ax1.set_title('📊 Top 15 Most Important Features', fontsize=14, fontweight='bold')
        ax1.set_xlim(0, top_features['avg_importance'].max() * 1.1)
        
        # Add value labels
        for i, (bar, importance) in enumerate(zip(bars, top_features['avg_importance'])):
            width = bar.get_width()
            ax1.text(width + 0.001, bar.get_y() + bar.get_height()/2.,
                    f'{importance:.3f}', ha='left', va='center', fontweight='bold')
        
        # 2. Feature Categories Breakdown
        category_importance = {}
        for category, features in FEATURE_CATEGORIES.items():
            category_features = feature_importance[
                feature_importance['feature'].isin(features)]
            category_importance[category] = category_features['avg_importance'].sum()
        
        categories = list(category_importance.keys())
        importances = list(category_importance.values())
        
        wedges, texts, autotexts = ax2.pie(importances, labels=categories, autopct='%1.1f%%',
                                          startangle=90, colors=plt.cm.Set2.colors)
        ax2.set_title('📈 Feature Categories Breakdown', fontsize=14, fontweight='bold')
        
        # Make percentage text bold and white
        for autotext in autotexts:
            autotext.set_color('white')
            autotext.set_fontweight('bold')
        
        plt.tight_layout()
        plt.savefig('feature_importance_analysis.png', dpi=self.dpi, bbox_inches='tight')
        plt.show()
        return fig
    
    def create_temporal_analysis_chart(self, alerts_with_time: List[Dict[str, Any]]) -> plt.Figure:
        """Create temporal analysis visualization"""
        print("Generating temporal analysis charts...")
        
        if not alerts_with_time:
            print("No temporal data available for visualization")
            return None
        
        # Extract temporal features
        hours = [a['start_hour'] for a in alerts_with_time]
        alerts_per_hour = Counter(hours)
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))
        fig.suptitle('⏰ Temporal Analysis of Alert Patterns', fontsize=16, fontweight='bold')
        
        # 1. Alert Distribution by Hour
        hours_data = sorted(alerts_per_hour.items())
        hours_x, hours_y = zip(*hours_data)
        
        ax1.plot(hours_x, hours_y, marker='o', linewidth=3, markersize=8, color='#FF6B6B')
        ax1.fill_between(hours_x, hours_y, alpha=0.3, color='#FF6B6B')
        ax1.set_xlabel('Hour of Day')
        ax1.set_ylabel('Number of Alerts')
        ax1.set_title('📊 Alert Volume by Hour of Day', fontsize=14, fontweight='bold')
        ax1.set_xticks(range(0, 24, 2))
        ax1.grid(True, alpha=0.3)
        
        # Highlight peak hours
        max_hour = max(hours_data, key=lambda x: x[1])
        ax1.annotate(f'Peak: {max_hour[1]} alerts\nat {max_hour[0]:02d}:00', 
                    xy=(max_hour[0], max_hour[1]), xytext=(max_hour[0]+3, max_hour[1]+10),
                    arrowprops=dict(arrowstyle='->', color='red'), fontsize=10, fontweight='bold')
        
        # 2. Alert Severity Distribution Over Time
        severity_hours = {}
        for alert in alerts_with_time:
            hour = alert['start_hour']
            severity = alert.get('severity', 'unknown').lower()
            if hour not in severity_hours:
                severity_hours[hour] = Counter()
            severity_hours[hour][severity] += 1
        
        severities = ['critical', 'warning', 'error', 'info']
        colors = ['#DC143C', '#FFA500', '#FF0000', '#32CD32']
        
        for i, severity in enumerate(severities):
            severity_counts = [severity_hours.get(hour, Counter()).get(severity, 0) for hour in range(24)]
            ax2.plot(range(24), severity_counts, label=severity.title(), 
                    color=colors[i], linewidth=2, marker='o', markersize=4)
        
        ax2.set_xlabel('Hour of Day')
        ax2.set_ylabel('Number of Alerts')
        ax2.set_title('🚨 Alert Severity Patterns', fontsize=14, fontweight='bold')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig('temporal_analysis_overview.png', dpi=self.dpi, bbox_inches='tight')
        plt.show()
        return fig
    
    def create_service_network_visualization(self, service_graph: nx.DiGraph) -> plt.Figure:
        """Create service network visualization"""
        print("Generating service network visualization...")
        
        if not service_graph or len(service_graph) == 0:
            print("No service graph data available for visualization")
            return None
        
        # Create simplified network for visualization (top services only)
        centrality = nx.degree_centrality(service_graph)
        top_services = sorted(centrality.items(), key=lambda x: x[1], reverse=True)[:20]
        
        if not top_services:
            print("No services with centrality data available")
            return None
        
        # Create subgraph with top services
        top_service_names = [service for service, _ in top_services]
        connected_services = set(top_service_names)
        
        # Add connected neighbors
        for service in top_service_names[:10]:  # Limit to prevent too many nodes
            neighbors = list(service_graph.neighbors(service))[:5]  # Top 5 neighbors
            connected_services.update(neighbors)
        
        subgraph = service_graph.subgraph(list(connected_services))
        
        fig, ax = plt.subplots(1, 1, figsize=(16, 12))
        
        # Calculate layout
        pos = nx.spring_layout(subgraph, k=3, iterations=50)
        
        # Draw network
        node_sizes = [centrality[node] * 2000 for node in subgraph.nodes()]
        node_colors = [centrality[node] for node in subgraph.nodes()]
        
        nx.draw(subgraph, pos, ax=ax, 
                node_size=node_sizes, 
                node_color=node_colors,
                cmap=plt.cm.Reds,
                alpha=0.8,
                edge_color='gray',
                width=0.5,
                with_labels=False)
        
        # Add labels for top services only
        top_labels = {service: service.split('-')[-1][:15] for service, _ in top_services[:10]}
        nx.draw_networkx_labels(subgraph, pos, top_labels, font_size=8, ax=ax)
        
        ax.set_title('🌐 Service Dependency Network\n(Top Services by Centrality)', 
                    fontsize=14, fontweight='bold')
        
        # Create legend
        import matplotlib.patches as mpatches
        legend_elements = [mpatches.Patch(color=plt.cm.Reds(0.8), label='High Centrality'),
                          mpatches.Patch(color=plt.cm.Reds(0.4), label='Medium Centrality'),
                          mpatches.Patch(color=plt.cm.Reds(0.2), label='Low Centrality')]
        ax.legend(handles=legend_elements, loc='upper right')
        
        plt.tight_layout()
        plt.savefig('service_network_visualization.png', dpi=self.dpi, bbox_inches='tight')
        plt.show()
        return fig
    
    def create_comprehensive_dashboard(self, processor_data: Dict[str, Any], 
                                     classified_alerts: List[Dict[str, Any]], 
                                     alerts_with_time: List[Dict[str, Any]], 
                                     service_graph: nx.DiGraph = None) -> plt.Figure:
        """Create comprehensive visualization dashboard"""
        print("🎨 Creating comprehensive AIOs dashboard...")
        
        # Create large figure with multiple subplots
        fig = plt.figure(figsize=self.figure_size)
        
        # Define grid layout
        gs = fig.add_gridspec(4, 4, hspace=0.3, wspace=0.3)
        
        # Main title
        fig.suptitle('🚀 AIOps Alert Processing Pipeline - Comprehensive Dashboard', 
                    fontsize=20, fontweight='bold', y=0.98)
        
        self._create_dashboard_pipeline_overview(fig, gs[0, :2], processor_data)
        self._create_dashboard_efficiency_metrics(fig, gs[0, 2], processor_data)
        self._create_dashboard_rca_distribution(fig, gs[0, 3], classified_alerts)
        self._create_dashboard_model_performance(fig, gs[1, :2], processor_data)
        self._create_dashboard_feature_importance(fig, gs[1, 2:], processor_data)
        self._create_dashboard_timeline(fig, gs[2, :], alerts_with_time)
        self._create_dashboard_high_priority(fig, gs[3, :2], classified_alerts)
        self._create_dashboard_summary_stats(fig, gs[3, 2:], processor_data)
        
        plt.tight_layout()
        plt.savefig('aiops_comprehensive_dashboard.png', dpi=self.dpi, bbox_inches='tight')
        plt.show()
        
        print(f"✅ Comprehensive dashboard saved as: aiops_comprehensive_dashboard.png")
        return fig
    
    def _create_dashboard_pipeline_overview(self, fig, gs_pos, processor_data):
        """Create pipeline overview section"""
        ax = fig.add_subplot(gs_pos)
        
        stages = ['Original\nAlerts', 'Enriched\nAlerts', 'Deduplicated\nAlerts', 'Consolidated\nGroups']
        counts = [
            processor_data['original_count'],
            processor_data['enriched_count'],
            processor_data['deduplicated_count'],
            processor_data['consolidated_count']
        ]
        
        bars = ax.bar(stages, counts, color=self.colors, alpha=0.8, edgecolor='black', linewidth=1)
        ax.set_title('📊 Pipeline Processing Overview', fontsize=14, fontweight='bold')
        ax.set_ylabel('Count')
        
        for bar, count in zip(bars, counts):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 5,
                    f'{count}', ha='center', va='bottom', fontweight='bold', fontsize=12)
        
        # Add flow arrows
        for i in range(len(stages)-1):
            ax.annotate('→', xy=(i+0.5, max(counts)/2), fontsize=20, ha='center', va='center')
    
    def _create_dashboard_efficiency_metrics(self, fig, gs_pos, processor_data):
        """Create efficiency metrics section"""
        ax = fig.add_subplot(gs_pos)
        
        original_count = processor_data['original_count']
        deduplicated_count = processor_data['deduplicated_count']
        enriched_count = processor_data['enriched_count']
        
        dedup_rate = ((original_count - deduplicated_count) / original_count) * 100
        enrichment_rate = (enriched_count / original_count) * 100
        
        metrics = ['Deduplication\nRate', 'Enrichment\nRate']
        values = [dedup_rate, enrichment_rate]
        
        bars = ax.bar(metrics, values, color=self.metrics_colors, alpha=0.8)
        ax.set_title('⚡ Processing Efficiency', fontsize=12, fontweight='bold')
        ax.set_ylabel('Percentage (%)')
        
        for bar, value in zip(bars, values):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 1,
                    f'{value:.1f}%', ha='center', va='bottom', fontweight='bold')
    
    def _create_dashboard_rca_distribution(self, fig, gs_pos, classified_alerts):
        """Create RCA distribution section"""
        ax = fig.add_subplot(gs_pos)
        
        rca_categories = Counter(group['final_rca_category'] for group in classified_alerts)
        
        # Take top 5 categories
        top_categories = dict(rca_categories.most_common(5))
        labels = [cat.replace('_', ' ').title()[:12] for cat in top_categories.keys()]
        sizes = list(top_categories.values())
        
        if sizes:
            wedges, texts, autotexts = ax.pie(sizes, labels=labels, autopct='%1.0f%%',
                                              startangle=90, colors=plt.cm.Set3.colors)
            ax.set_title('🎯 RCA Categories', fontsize=12, fontweight='bold')
            
            for autotext in autotexts:
                autotext.set_fontweight('bold')
                autotext.set_fontsize(9)
    
    def _create_dashboard_model_performance(self, fig, gs_pos, processor_data):
        """Create model performance section"""
        ax = fig.add_subplot(gs_pos)
        
        model_performance = processor_data.get('model_performance', {})
        if model_performance:
            models = list(model_performance.keys())
            cv_scores = [model_performance[model]['cv_score'] * 100 for model in models]
            
            bars = ax.barh(models, cv_scores, color=plt.cm.viridis(np.linspace(0, 1, len(models))))
            ax.set_title('🏆 Model Performance Comparison', fontsize=14, fontweight='bold')
            ax.set_xlabel('Cross-Validation Accuracy (%)')
            
            # Highlight best model
            best_model = processor_data.get('best_model')
            if best_model and best_model in models:
                best_idx = models.index(best_model)
                bars[best_idx].set_color('#FFD700')
                bars[best_idx].set_edgecolor('red')
                bars[best_idx].set_linewidth(3)
            
            for bar, score in zip(bars, cv_scores):
                width = bar.get_width()
                ax.text(width + 0.5, bar.get_y() + bar.get_height()/2.,
                        f'{score:.1f}%', ha='left', va='center', fontweight='bold')
    
    def _create_dashboard_feature_importance(self, fig, gs_pos, processor_data):
        """Create feature importance section"""
        ax = fig.add_subplot(gs_pos)
        
        feature_importance = processor_data.get('feature_importance')
        if feature_importance is not None and len(feature_importance) > 0:
            top_features = feature_importance.head(10)
            y_pos = range(len(top_features))
            
            bars = ax.barh(y_pos, top_features['avg_importance'], 
                          color=plt.cm.plasma(np.linspace(0, 1, len(top_features))))
            ax.set_yticks(y_pos)
            ax.set_yticklabels([f.replace('_', ' ').title()[:15] for f in top_features['feature']], 
                              fontsize=10)
            ax.set_xlabel('Importance Score')
            ax.set_title('🧠 Top Feature Importance', fontsize=14, fontweight='bold')
            
            for bar, importance in zip(bars, top_features['avg_importance']):
                width = bar.get_width()
                ax.text(width + 0.001, bar.get_y() + bar.get_height()/2.,
                        f'{importance:.3f}', ha='left', va='center', fontweight='bold')
    
    def _create_dashboard_timeline(self, fig, gs_pos, alerts_with_time):
        """Create timeline section"""
        ax = fig.add_subplot(gs_pos)
        
        if alerts_with_time:
            hours = [a['start_hour'] for a in alerts_with_time]
            alerts_per_hour = Counter(hours)
            
            hours_data = sorted(alerts_per_hour.items())
            hours_x, hours_y = zip(*hours_data) if hours_data else ([], [])
            
            ax.plot(hours_x, hours_y, marker='o', linewidth=3, markersize=6, color='#FF6B6B')
            ax.fill_between(hours_x, hours_y, alpha=0.3, color='#FF6B6B')
            ax.set_xlabel('Hour of Day')
            ax.set_ylabel('Alert Count')
            ax.set_title('⏰ Alert Volume by Hour', fontsize=14, fontweight='bold')
            ax.set_xticks(range(0, 24, 2))
            ax.grid(True, alpha=0.3)
        else:
            ax.text(0.5, 0.5, 'No Temporal Data Available', ha='center', va='center', 
                    transform=ax.transAxes, fontsize=14)
            ax.set_title('⏰ Alert Timeline', fontsize=14, fontweight='bold')
    
    def _create_dashboard_high_priority(self, fig, gs_pos, classified_alerts):
        """Create high priority incidents section"""
        ax = fig.add_subplot(gs_pos)
        
        high_priority = [g for g in classified_alerts 
                        if g['total_alerts'] > 2 or 'critical' in g['final_rca_category']]
        
        if high_priority:
            top_incidents = sorted(high_priority, key=lambda x: x['total_alerts'], reverse=True)[:5]
            
            incident_names = [incident['primary_alert'].get('service_name', 'Unknown')[:20] 
                            for incident in top_incidents]
            alert_counts = [incident['total_alerts'] for incident in top_incidents]
            
            x_pos = range(len(incident_names))
            bars = ax.bar(x_pos, alert_counts, color=plt.cm.Reds(np.linspace(0.3, 1, len(incident_names))))
            
            ax.set_xticks(x_pos)
            ax.set_xticklabels(incident_names, rotation=45, ha='right', fontsize=10)
            ax.set_ylabel('Alert Count')
            ax.set_title('🚨 Top High-Priority Incidents', fontsize=14, fontweight='bold')
            
            # Add alert count labels
            for i, (bar, count) in enumerate(zip(bars, alert_counts)):
                ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.2,
                        f'{count} alerts', ha='center', va='bottom', 
                        fontsize=9, fontweight='bold')
        else:
            ax.text(0.5, 0.5, 'No High-Priority Incidents Found', ha='center', va='center',
                    transform=ax.transAxes, fontsize=12)
            ax.set_title('🚨 High-Priority Incidents', fontsize=14, fontweight='bold')
    
    def _create_dashboard_summary_stats(self, fig, gs_pos, processor_data):
        """Create summary statistics section"""
        ax = fig.add_subplot(gs_pos)
        ax.axis('off')
        
        # Calculate summary stats
        stats_text = f"""
📊 PIPELINE SUMMARY STATISTICS
═══════════════════════════════════

🔢 Processing Metrics:
• Original Alerts: {processor_data['original_count']:,}
• Graph Enriched: {processor_data['enriched_count']:,} ({processor_data['enriched_count']/processor_data['original_count']*100:.1f}%)
• After Deduplication: {processor_data['deduplicated_count']:,}
• Consolidated Groups: {processor_data['consolidated_count']:,}

🎯 Enhancement Results:
• Exact Matches: {processor_data.get('exact_matches', 0)}}
• Fuzzy Matches: {processor_data.get('fuzzy_matches', 0)}}
• Deduplication Rate: {((processor_data['original_count'] - processor_data['deduplicated_count']) / processor_data['original_count'] * 100):.1f}%
• Enrichment Rate: {(processor_data['enriched_count']/processor_data['original_count']*100):.1f}%

🧠 ML Performance:
• Best Model: {processor_data.get('best_model', 'N/A')}
• Features Selected: {len(processor_data.get('best_features', []))}
• Models Trained: {len(processor_data.get('models', {}))}

🚨 Critical Issues:
• High-Priority Groups: {processor_data.get('high_priority_groups', 0)}
• Cascading Failures: {processor_data.get('cascading_failures', 0)}
• Avg Confidence: {processor_data.get('avg_confidence', 0):.1f}%
        """
        
        ax.text(0.05, 0.95, stats_text, transform=ax.transAxes, fontsize=11,
                verticalalignment='top', fontfamily='monospace',
                bbox=dict(boxstyle="round,pad=0.5", facecolor="lightblue", alpha=0.8))
    
    def generate_comprehensive_report(self, processor_data: Dict[str, Any], 
                                   classified_alerts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate final comprehensive report"""
        print("\n" + "="*70)
        print("COMPREHENSIVE AIOPS ALERT PROCESSING & RCA CLASSIFICATION")
        print("="*70)
        
        # Processing statistics
        original_count = processor_data['original_count']
        enriched_count = processor_data['enriched_count']
        deduplicated_count = processor_data['deduplicated_count']
        consolidated_count = processor_data['consolidated_count']
        
        print(f"\nPROCESSING PIPELINE RESULTS:")
        print(f"  Original firing alerts: {original_count}")
        print(f"  Graph-enriched alerts: {enriched_count} ({enriched_count/original_count*100:.1f}%)")
        print(f"  After deduplication: {deduplicated_count}")
        print(f"  Consolidated groups: {consolidated_count}")
        
        # Deduplication effectiveness
        dedup_reduction = ((original_count - deduplicated_count) / original_count * 100) if original_count > 0 else 0
        print(f"  Deduplication reduction: {dedup_reduction:.1f}%")
        
        # RCA classification results
        rca_categories = Counter(group['final_rca_category'] for group in classified_alerts)
        
        print(f"\nRCA CLASSIFICATION RESULTS:")
        for category, count in rca_categories.most_common():
            print(f"  {category}: {count} groups")
        
        # High-priority issues
        high_priority = [
            g for g in classified_alerts 
            if g['total_alerts'] > 2 or 'critical' in g['final_rca_category'] or 'cascading' in g['final_rca_category']
        ]
        
        print(f"\nHIGH-PRIORITY RCA GROUPS: {len(high_priority)}")
        for i, group in enumerate(sorted(high_priority, key=lambda x: x['total_alerts'], reverse=True)[:5], 1):
            primary = group['primary_alert']
            print(f"  {i}. {group['final_rca_category']} ({group['total_alerts']} alerts)")
            print(f"     Service: {primary.get('service_name', 'Unknown')}")
            print(f"     Resource: {primary.get('anomaly_resource_type', primary.get('resource_type', 'Unknown'))}")
            print(f"     Confidence: {group.get('ml_confidence', 0):.2f}")
        
        return {
            'original_alerts': original_count,
            'deduplicated_alerts': deduplicated_count,
            'consolidated_groups': consolidated_count,
            'rca_categories': dict(rca_categories),
            'high_priority_groups': len(high_priority)
        }
    
    def save_results(self, deduplicated_alerts: List[Dict[str, Any]], 
                    classified_alerts: List[Dict[str, Any]]) -> None:
        """Save all processing results"""
        print(f"\nSAVING COMPREHENSIVE RESULTS")
        
        # Save deduplicated alerts
        if deduplicated_alerts:
            pd.DataFrame(deduplicated_alerts).to_csv('deduplicated_alerts.csv', index=False)
            print(f"  Deduplicated alerts: deduplicated_alerts.csv")
        
        # Save consolidated groups with RCA classification
        if classified_alerts:
            consolidated_data = []
            for group in classified_alerts:
                primary = group['primary_alert']
                consolidated_data.append({
                'group_id': group['group_id'],
                'rca_category': group['final_rca_category'],
                'ml_confidence': group.get('ml_confidence', 0),
                'alert_count': group['total_alerts'],
                'relationship_type': group['relationship_type'],
                'service_name': primary.get('service_name', ''),
                'resource_type': primary.get('anomaly_resource_type', ''),
                'severity': primary.get('severity', ''),
                'description': primary.get('description', '')[:200],
                'has_graph_context': primary.get('has_graph_context', False),
                'service_centrality': primary.get('service_centrality', 0),
                'calls_services': ', '.join(primary.get('calls_services', [])),
                'called_by_services': ', '.join(primary.get('called_by_services', []))
            })
            
            pd.DataFrame(consolidated_data).to_csv('rca_classified_alerts.csv', index=False)
            print(f"  RCA classified alerts: rca_classified_alerts.csv")
        
        print(f"\nComplete processing pipeline finished!")
