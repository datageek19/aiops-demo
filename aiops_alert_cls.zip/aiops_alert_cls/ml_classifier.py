"""
Machine learning classification module for AIOps Alert Pipeline
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Any, Tuple
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import LabelEncoder, StandardScaler, MinMaxScaler, RobustScaler
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.feature_selection import SelectKBest, SelectFromModel, RFE, mutual_info_classif
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from collections import Counter
import warnings

warnings.filterwarnings('ignore')

# Try importing optional ML libraries
try:
    import xgboost as xgb
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False

try:
    import lightgbm as lgb
    LIGHTGBM_AVAILABLE = True
except ImportError:
    LIGHTGBM_AVAILABLE = False

from config import ML_CONFIG, RCA_CATEGORIES


class MLClassifier:
    """
    Handles machine learning model training and RCA classification
    """
    
    def __init__(self):
        self.models = {}
        self.model_performance = {}
        self.best_model = None
        self.rca_classifier = None
        self.rca_scaler = None
        self.rca_label_encoder = None
        self.feature_selector = None
        self.feature_importance = None
        self.scalers = {}
        self.best_features = []
        
    def prepare_advanced_features(self, consolidated_groups: List[Dict[str, Any]]) -> Tuple[pd.DataFrame, List[str]]:
        """Prepare enhanced features for ML-based RCA classification"""
        print("Preparing advanced features for RCA classification...")
        
        features = []
        labels = []
        
        for group in consolidated_groups:
            primary_alert = group['primary_alert']
            
            # Basic alert characteristics
            alert_count = group['total_alerts']
            has_graph_context = 1 if primary_alert.get('has_graph_context') else 0
            service_centrality = primary_alert.get('service_centrality', 0)
            is_duplicate = 1 if primary_alert.get('is_duplicate', False) else 0
            duplicate_count = primary_alert.get('duplicate_count', 1)
            
            feature_vector = self._extract_feature_vector(primary_alert, alert_count, has_graph_context, 
                                                        service_centrality, is_duplicate, duplicate_count)
            
            features.append(feature_vector)
            labels.append(group['rca_category'])
        
        classification_features = pd.DataFrame(features)
        
        print(f"Prepared {len(features)} advanced feature vectors with {len(classification_features.columns)} features")
        print(f"Feature categories: Core, Resource, Relationship, Temporal, Environment, Entity, Severity, Description, Graph, Intensity")
        
        return classification_features, labels
    
    def _extract_feature_vector(self, alert: Dict[str, Any], alert_count: int, has_graph_context: int, 
                               service_centrality: float, is_duplicate: int, duplicate_count: int) -> Dict[str, Any]:
        """Extract comprehensive feature vector from alert data"""
        
        # Enhanced resource analysis
        resource_type = str(alert.get('anomaly_resource_type', '')).lower()
        resource_features = {
            'resource_memory': 1 if 'memory' in resource_type else 0,
            'resource_cpu': 1 if 'cpu' in resource_type else 0,
            'resource_network': 1 if 'network' in resource_type else 0,
            'resource_disk': 1 if 'disk' in resource_type else 0,
            'resource_traffic': 1 if 'traffic' in resource_type else 0,
            'resource_storage': 1 if 'storage' in resource_type else 0,
        }
        
        # Relationship complexity features
        calls_count = len(alert.get('calls_services', []))
        called_by_count = len(alert.get('called_by_services', []))
        belongs_to_count = len(alert.get('belongs_to_services', []))
        owns_count = len(alert.get('owns_services', []))
        
        # Advanced relationship features
        total_dependencies = calls_count + called_by_count
        dependency_ratio = calls_count / (called_by_count + 1)  # Avoid division by zero
        relationship_complexity = len(set(
            alert.get('calls_services', []) + 
            alert.get('called_by_services', [])
        ))
        
        # Temporal features with engineering
        hour_of_day = alert.get('start_hour', 0)
        hour_sin = np.sin(2 * np.pi * hour_of_day / 24)
        hour_cos = np.cos(2 * np.pi * hour_of_day / 24)
        duration_minutes = alert.get('duration_minutes', 0)
        weekday = pd.to_datetime(alert.get('starts_at', '')).weekday() if alert.get('starts_at') else 0
        
        # Service environment features
        cluster_name = str(alert.get('cluster', '')).lower()
        namespace = str(alert.get('namespace', '')).lower()
        environment_features = {
            'prod_environment': 1 if 'prod' in cluster_name else 0,
            'staging_environment': 1 if 'staging' in cluster_name else 0,
            'dev_environment': 1 if 'dev' in cluster_name else 0,
            'network_namespace': 1 if 'network' in namespace else 0,
            'default_namespace': 1 if namespace == 'default' else 0,
        }
        
        # Entity type analysis
        entity_type = str(alert.get('anomaly_entity_type', '')).lower()
        entity_features = {
            'entity_type_pod': 1 if 'pod' in entity_type else 0,
            'entity_type_service': 1 if 'service' in entity_type else 0,
            'entity_type_node': 1 if 'node' in entity_type else 0,
            'entity_type_deployment': 1 if 'deployment' in entity_type else 0,
        }
        
        # Severity analysis
        severity = str(alert.get('severity', '')).lower()
        severity_features = {
            'severity_warning': 1 if 'warning' in severity else 0,
            'severity_critical': 1 if 'critical' in severity else 0,
            'severity_error': 1 if 'error' in severity else 0,
            'severity_info': 1 if 'info' in severity else 0,
        }
        
        # Alert description analysis
        description = str(alert.get('description', '')).lower()
        description_features = {
            'desc_len': len(description),
            'desc_has_high': 1 if 'high' in description else 0,
            'desc_has_failed': 1 if 'fail' in description else 0,
            'desc_has_error': 1 if 'error' in description else 0,
            'desc_has_threshold': 1 if 'threshold' in description else 0,
            'desc_has_response': 1 if 'response' in description else 0,
            'desc_word_count': len(description.split()),
        }
        
        # Graph topology features
        graph_features = {
            'graph_betweenness': service_centrality,  # Use centrality as proxy
            'isolated_service': 1 if not has_graph_context else 0,
            'highly_connected': 1 if service_centrality > 0.1 else 0,
        }
        
        # Alert intensity features
        intensity_features = {
            'alert_frequency_per_hour': alert_count / max(duration_minutes / 60, 1),
            'avg_alerts_per_service': alert_count / max(total_dependencies + 1, 1),
            'duplicate_intensity': duplicate_count / alert_count if alert_count > 0 else 0,
        }
        
        # Combine all features
        feature_vector = {
            # Core features
            'alert_count': alert_count,
            'has_graph_context': has_graph_context,
            'service_centrality': service_centrality,
            'is_duplicate': is_duplicate,
            'duplicate_count': duplicate_count,
            
            # Resource features
            **resource_features,
            
            # Relationship features
            'calls_count': calls_count,
            'called_by_count': called_by_count,
            'belongs_to_count': belongs_to_count,
            'owns_count': owns_count,
            'total_dependencies': total_dependencies,
            'dependency_ratio': dependency_ratio,
            'relationship_complexity': relationship_complexity,
            
            # Temporal features
            'hour_of_day': hour_of_day,
            'hour_sin': hour_sin,
            'hour_cos': hour_cos,
            'duration_minutes': duration_minutes,
            'weekday': weekday,
            
            # Environment features
            **environment_features,
            
            # Entity features  
            **entity_features,
            
            # Severity features
            **severity_features,
            
            # Description features
            **description_features,
            
            # Graph features
            **graph_features,
            
            # Intensity features
            **intensity_features,
        }
        
        return feature_vector
    
    def feature_selection_and_preprocessing(self, X: pd.DataFrame, y: List[str]) -> Tuple[np.ndarray, np.ndarray]:
        """Advanced feature selection and preprocessing"""
        print("Performing feature selection and preprocessing...")
        
        # Fill missing values
        X_filled = X.fillna(0)
        
        # Handle infinite values
        X_filled = X_filled.replace([np.inf, -np.inf], 0)
        
        # Encode labels
        self.rca_label_encoder = LabelEncoder()
        y_encoded = self.rca_label_encoder.fit_transform(y)
        
        # Split data for feature selection
        X_train, X_test, y_train, y_test = train_test_split(
            X_filled, y_encoded, test_size=ML_CONFIG['test_size'], 
            random_state=ML_CONFIG['random_state'], stratify=y_encoded
        )
        
        # Multiple preprocessing approaches
        self.scalers['standard'] = StandardScaler()
        self.scalers['robust'] = RobustScaler()
        self.scalers['minmax'] = MinMaxScaler()
        
        # Feature selection strategies
        total_features = X_filled.shape[1]
        selection_methods = {
            'univariate': SelectKBest(score_func=mutual_info_classif, k=min(ML_CONFIG['feature_selection_k'], total_features//3)),
            'model_based': SelectFromModel(RandomForestClassifier(n_estimators=50, random_state=42)),
            'recursive': RFE(estimator=RandomForestClassifier(n_estimators=50, random_state=42), n_features_to_select=min(15, total_features//4))
        }
        
        best_score = 0
        best_features = X_filled.columns.tolist()
        best_scaler = 'standard'
        
        # Default fallback scaler
        fallback_scaler = StandardScaler()
        self.rca_scaler = fallback_scaler
        
        for scaler_name, scaler in self.scalers.items():
            for method_name, selector in selection_methods.items():
                try:
                    # Scale features
                    X_scaled = scaler.fit_transform(X_train)
                    
                    # Select features
                    if hasattr(selector, 'fit_transform'):
                        X_selected = selector.fit_transform(X_scaled, y_train)
                    else:
                        selector.fit(X_scaled, y_train)
                        X_selected = selector.transform(X_scaled)
                    
                    selected_features = X_filled.columns[selector.get_support()].tolist()
                    
                    # Quick performance check with RandomForest
                    temp_rf = RandomForestClassifier(n_estimators=50, random_state=42)
                    score = temp_rf.fit(X_selected, y_train).score(X_selected, y_train)
                    
                    if score > best_score:
                        best_score = score
                        best_scaler = scaler_name
                        best_features = selected_features
                        self.feature_selector = selector
                        # Fit scaler only on selected features for self.rca_scaler.fit(X_train_selected)
                        
                except Exception as e:
                    print(f"Feature selection method {method_name} with {scaler_name}, attempting fallback...")
                    continue
        
        print(f"Best feature selection: {len(best_features)} features selected")
        print(f"Best scaling: {best_scaler}")
        
        # Fallback if no methods worked
        if self.rca_scaler is None:
            print("Using fallback scaler (StandardScaler)")
            self.rca_scaler = StandardScaler()
            # If feature selection failed completely, use top features by variance
            if len(best_features) == total_features:
                print("Feature selection failed, using top variance features...")
                variances = X_filled.var().sort_values(ascending=False)
                best_features = variances.head(min(20, total_features)).index.tolist()
                print(f"Selected top {len(best_features)} features by variance")
            
            # Fit scaler on selected features
            X_filled_selected = X_filled[best_features]
            self.rca_scaler.fit(X_filled_selected)
        
        self.best_features = best_features
        return self.rca_scaler.transform(X_filled[best_features]), y_encoded
    
    def train_multiple_models(self, X_scaled: np.ndarray, y_encoded: np.ndarray):
        """Train multiple ML models and compare performance"""
        print("Training multiple ML models...")
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled, y_encoded, test_size=ML_CONFIG['test_size'], 
            random_state=ML_CONFIG['random_state'], stratify=y_encoded
        )
        
        # Define models with hyperparameters
        models_config = self._get_models_config()
        
        # Train and evaluate all models
        best_score = 0
        
        for model_name, model in models_config.items():
            try:
                print(f"Training {model_name}...")
                
                # Train model
                model.fit(X_train, y_train)
                
                # Evaluate
                train_score = model.score(X_train, y_train)
                cv_score = cross_val_score(model, X_train, y_train, 
                                         cv=ML_CONFIG['cv_folds'], scoring='accuracy').mean()
                
                # Store model and performance
                self.models[model_name] = model
                self.model_performance[model_name] = {
                    'train_score': train_score,
                    'cv_score': cv_score,
                    'test_score': model.score(X_test, y_test)
                }
                
                print(f"{model_name}: Train={train_score:.3f}, CV={cv_score:.3f}, Test={model.score(X_test, y_test):.3f}")
                
                # Update best model
                if cv_score > best_score:
                    best_score = cv_score
                    self.best_model = model_name
                    self.rca_classifier = model
                    
            except Exception as e:
                print(f"Error training {model_name}: {e}")
                continue
        
        print(f"\nBest performing model: {self.best_model} (CV Score: {best_score:.3f})")
        return self.rca_classifier
    
    def _get_models_config(self) -> Dict[str, Any]:
        """Get configured ML models"""
        models_config = {
            'RandomForest': RandomForestClassifier(**ML_CONFIG['models']['RandomForest'], 
                                                  random_state=ML_CONFIG['random_state']),
            'ExtraTrees': ExtraTreesClassifier(**ML_CONFIG['models']['ExtraTrees'], 
                                              random_state=ML_CONFIG['random_state']),
            'GradientBoosting': GradientBoostingClassifier(**ML_CONFIG['models']['GradientBoosting'], 
                                                          random_state=ML_CONFIG['random_state']),
            'LogisticRegression': LogisticRegression(**ML_CONFIG['models']['LogisticRegression'], 
                                                    random_state=ML_CONFIG['random_state']),
            'SVM': SVC(**ML_CONFIG['models']['SVM'], random_state=ML_CONFIG['random_state']),
            'NeuralNetwork': MLPClassifier(**ML_CONFIG['models']['NeuralNetwork'], 
                                          random_state=ML_CONFIG['random_state'])
        }
        
        # Add XGBoost and LightGBM if available
        if XGBOOST_AVAILABLE:
            models_config['XGBoost'] = xgb.XGBClassifier(**ML_CONFIG['models']['XGBoost'], 
                                                        random_state=ML_CONFIG['random_state'])
        
        if LIGHTGBM_AVAILABLE:
            models_config['LightGBM'] = lgb.LGBMClassifier(**ML_CONFIG['models']['LightGBM'], 
                                                           random_state=ML_CONFIG['random_state'])
        
        return models_config
    
    def extract_feature_importance(self):
        """Extract and analyze feature importance across models"""
        print("Analyzing feature importance...")
        
        importance_data = []
        
        for model_name, model in self.models.items():
            try:
                if hasattr(model, 'feature_importances_'):
                    importances = model.feature_importances_
                    importance_data.append({
                        'model': model_name,
                        'importance': importances,
                        'length': len(importances)
                    })
                elif hasattr(model, 'coef_'):
                    # For logistic regression
                    coef_importances = np.abs(model.coef_[0]) if model.coef_.ndim > 1 else np.abs(model.coef_)
                    importance_data.append({
                        'model': model_name,
                        'importance': coef_importances,
                        'length': len(coef_importances)
                    })
            except Exception as e:
                print(f"Could not extract importance from {model_name}: {e}")
                continue
        
        if importance_data:
            # Use the most common length
            lengths = [data['length'] for data in importance_data]
            most_common_length = max(set(lengths), key=lengths.count)
            
            # Filter data to only include arrays of the correct length
            filtered_data = [data for data in importance_data if data['length'] == most_common_length]
            
            if filtered_data:
                # Average importance across models with same length
                avg_importance = np.mean([data['importance'] for data in filtered_data], axis=0)
                
                # Use best_features as feature names
                if len(self.best_features) == most_common_length:
                    feature_names = self.best_features
                else:
                    # Fallback to generic names
                    feature_names = [f'feature_{i}' for i in range(most_common_length)]
                
                self.feature_importance = pd.DataFrame({
                    'feature': feature_names,
                    'avg_importance': avg_importance,
                    'model_count': len(filtered_data)
                }).sort_values('avg_importance', ascending=False)
                
                print("Top 15 Most Important Features (Averaged Across Models):")
                print(self.feature_importance.head(15))
            else:
                print("No compatible importance data found across models")
                self.feature_importance = None
        else:
            print("No importance data extracted from any models")
            self.feature_importance = None
            
        return self.feature_importance
    
    def train_advanced_classifier(self, consolidated_groups: List[Dict[str, Any]]):
        """Advanced multi-model RCA classification training"""
        print("Starting advanced RCA classifier training...")
        
        # Prepare features
        self.classification_features, self.classification_labels = self.prepare_advanced_features(consolidated_groups)
        
        X = self.classification_features
        y = self.classification_labels
        
        # Feature selection and preprocessing
        X_scaled, y_encoded = self.feature_selection_and_preprocessing(X, y)
        
        # Train multiple models
        self.rca_classifier = self.train_multiple_models(X_scaled, y_encoded)
        
        # Extract feature importance
        self.extract_feature_importance()
        
        return self.rca_classifier
    
    def classify_alerts_for_rca(self, consolidated_groups: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Classify consolidated alerts for RCA using advanced models"""
        print("Classifying alerts for RCA with advanced models...")
        
        if not self.rca_classifier:
            print("No model available. Training advanced classifier...")
            self.train_advanced_classifier(consolidated_groups)
        
        # Prepare features for prediction
        try:
            X_subset = self.classification_features[self.best_features].fillna(0)
        except (KeyError, AttributeError):
            print("Using all features as fallback...")
            X_subset = self.classification_features.fillna(0)
        
        X_subset = X_subset.replace([np.inf, -np.inf], 0)
        X_scaled = self.rca_scaler.transform(X_subset)
        
        # Predict RCA categories using best model
        predictions = self.rca_classifier.predict(X_scaled)
        
        # Get prediction probabilities if available
        try:
            probabilities = self.rca_classifier.predict_proba(X_scaled)
        except:
            probabilities = None
        
        # Update consolidated alerts with predictions
        for i, group in enumerate(consolidated_groups):
            predicted_category = self.rca_label_encoder.inverse_transform([predictions[i]])[0]
            
            # Calculate confidence
            if probabilities is not None:
                confidence = np.max(probabilities[i])
            else:
                confidence = 0.85 if group['total_alerts'] > 2 else 0.70
            
            group['ml_rca_category'] = predicted_category
            group['ml_confidence'] = confidence
            group['best_model'] = self.best_model
            group['final_rca_category'] = predicted_category
        
        return consolidated_groups
    
    def generate_model_comparison_report(self):
        """Generate model performance comparison report"""
        print("\nMODEL PERFORMANCE COMPARISON:")
        print("=" * 60)
        
        if not self.model_performance:
            print("No model performance data available")
            return
        
        # Sort models by CV score
        sorted_models = sorted(
            self.model_performance.items(),
            key=lambda x: x[1]['cv_score'],
            reverse=True
        )
        
        print("Model Performance Rankings:")
        print("-" * 60)
        print(f"{'Rank':<4} {'Model':<15} {'Train':<8} {'CV':<8} {'Test':<8} {'Accuracy Score'}")
        print("-" * 60)
        
        for rank, (model_name, perf) in enumerate(sorted_models, 1):
            print(f"{rank:<4} {model_name:<15} {perf['train_score']:<8.3f} {perf['cv_score']:<8.3f} {perf['test_score']:<8.3f} {perf['cv_score']:.1%}")
        
        print("-" * 60)
        print(f"Best Model: {self.best_model}")
        print(f"Feature Count: {len(self.best_features)}")
        print(f"Total Models Trained: {len(self.models)}")
        
        # Feature importance insights
        if self.feature_importance is not None:
            print(f"\nTop 5 Feature Categories:")
            print("-" * 30)
            for i, row in self.feature_importance.head(5).iterrows():
                print(f"{i+1}. {row['feature']}: {row['avg_importance']:.3f}")
        
        print("=" * 60)
