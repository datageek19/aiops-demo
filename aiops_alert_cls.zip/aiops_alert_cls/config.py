"""
Configuration and constants for AIOps Alert Processing Pipeline
"""

import warnings
warnings.filterwarnings('ignore')

# Data Processing Configuration
DATA_CONFIG = {
    'time_window_minutes': 5,
    'temporal_window_minutes': 30,  # For relationship grouping
    'description_similarity_threshold': 0.85,
    'min_centrality_threshold': 0.1,
    'high_centrality_threshold': 0.2
}

# ML Model Configuration
ML_CONFIG = {
    'test_size': 0.2,
    'random_state': 42,
    'cv_folds': 5,
    'feature_selection_k': 20,
    'models': {
        'RandomForest': {
            'n_estimators': 300,
            'max_depth': 15,
            'min_samples_split': 3,
            'min_samples_leaf': 1,
            'class_weight': 'balanced'
        },
        'ExtraTrees': {
            'n_estimators': 300,
            'max_depth': 15,
            'min_samples_split': 3,
            'min_samples_leaf': 1,
            'class_weight': 'balanced'
        },
        'GradientBoosting': {
            'n_estimators': 200,
            'learning_rate': 0.1,
            'max_depth': 8,
            'subsample': 0.8


        },
        'LogisticRegression': {
            'C': 1.0,
            'max_iter': 1000,
            'class_weight': 'balanced'
        },
        'SVM': {
            'C': 1.0,
            'kernel': 'rbf',
            'probability': True,
            'class_weight': 'balanced'
        },
        'NeuralNetwork': {
            'hidden_layer_sizes': (100, 50),
            'activation': 'relu',
            'solver': 'adam',
            'alpha': 0.001,
            'max_iter': 1000
        },
        'XGBoost': {
            'n_estimators': 200,
            'max_depth': 8,
            'learning_rate': 0.1,
            'subsample': 0.8,
            'eval_metric': 'logloss'
        },
        'LightGBM': {
            'n_estimators': 200,
            'max_depth': 8,
            'learning_rate': 0.1,
            'subsample': 0.8,
            'verbose': -1
        }
    }
}

# PCA Categories for RCA Classification
RCA_CATEGORIES = [
    'infrastructure_wide_failure',
    'cascading_service_failure', 
    'resource_exhaustion_critical_service',
    'memory_leak_or_pressure',
    'distributed_service_issue',
    'correlated_incidents',
    'storage_issue',
    'network_performance_issue',
    'critical_service_degradation',
    'isolated_service_issue',
    'unknown'
]

# Feature Categories for Analysis
FEATURE_CATEGORIES = {
    'Core': ['alert_count', 'has_graph_context', 'service_centrality'],
    'Resource': ['resource_memory', 'resource_cpu', 'resource_network', 'resource_disk'],
    'Relationship': ['total_dependencies', 'relationship_complexity', 'belongs_to_count'],
    'Temporal': ['hour_of_day', 'duration_minutes', 'hour_sin', 'hour_cos'],
    'Environment': ['prod_environment', 'staging_environment', 'network_namespace'],
    'Description': ['desc_len', 'desc_word_count', 'desc_has_error'],
    'Graph': ['graph_betweenness', 'isolated_service', 'highly_connected'],
    'Intensity': ['alert_frequency_per_hour', 'duplicate_intensity', 'avg_alerts_per_service']
}

# Visualization Configuration
VIZ_CONFIG = {
    'figure_size': (24, 16),
    'dpi': 300,
    'colors': ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4'],
    'metrics_colors': ['#FF9999', '#99CCFF'],
    'save_format': 'png'
}
