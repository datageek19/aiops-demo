"""
Temporal deduplication module for AIOps Alert Pipeline
"""

import difflib
import re
from typing import List, Dict, Any, Tuple
from datetime import datetime
from collections import Counter
from config import DATA_CONFIG


class AlertDeduplicator:
    """
    Handles temporal deduplication of alerts
    """
    
    def __init__(self):
        self.time_window_minutes = DATA_CONFIG['time_window_minutes']
        self.description_similarity_threshold = DATA_CONFIG['description_similarity_threshold']
    
    def temporal_deduplication(self, alerts: List[Dict[str, Any]], time_window_minutes: int = None) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """
        Remove temporal duplicates based on:
        1. Same service + resource type + severity
        2. Within time window
        3. Similar descriptions
        """
        if time_window_minutes is None:
            time_window_minutes = self.time_window_minutes
            
        print(f"Performing temporal deduplication (window: {time_window_minutes} minutes)...")
        
        # Sort alerts by timestamp
        sorted_alerts = sorted(
            [a for a in alerts if a.get('start_datetime')],
            key=lambda x: x['start_datetime']
        )
        
        deduplicated = []
        duplicate_groups = []
        processed_ids = set()
        
        for i, alert in enumerate(sorted_alerts):
            if alert.get('_id') in processed_ids:
                continue
            
            # Find duplicates within time window
            duplicates = [alert]
            
            for j in range(i + 1, len(sorted_alerts)):
                other_alert = sorted_alerts[j]
                
                if other_alert.get('_id') in processed_ids:
                    continue
                
                # Check time window
                time_diff = (other_alert['start_datetime'] - alert['start_datetime']).total_seconds() / 60
                if time_diff > time_window_minutes:
                    break  # Beyond time window
                
                # Check if it's a duplicate
                if self.is_temporal_duplicate(alert, other_alert):
                    duplicates.append(other_alert)
                    processed_ids.add(other_alert.get('_id'))
            
            if len(duplicates) > 1:
                # Create consolidated alert from duplicates
                consolidated = self.consolidate_duplicate_alerts(duplicates)
                deduplicated.append(consolidated)
                duplicate_groups.append({
                    'representative': consolidated,
                    'duplicates': duplicates[1:],
                    'count': len(duplicates)
                })
            else:
                # Single alert
                alert['is_duplicate'] = False
                alert['duplicate_count'] = 1
                deduplicated.append(alert)
            
            processed_ids.add(alert.get('_id'))
        
        original_count = len(alerts)
        final_count = len(deduplicated)
        reduction = original_count - final_count
        reduction_pct = (reduction / original_count * 100) if original_count > 0 else 0
        
        # Validation checks
        if reduction_pct > 50:
            print(f"WARNING: High deduplication rate ({reduction_pct:.1f}%) - may be over-aggressive")
        elif reduction_pct < 20:
            print(f"INFO: Conservative deduplication ({reduction_pct:.1f}%) - consider tightening criteria")
        
        print(f"Temporal deduplication: {original_count} → {final_count} alerts ({reduction} duplicates removed, {reduction_pct:.1f}%)")
        return deduplicated, duplicate_groups
    
    def is_temporal_duplicate(self, alert1: Dict[str, Any], alert2: Dict[str, Any]) -> bool:
        """Check if two alerts are temporal duplicates"""
        # Same service
        if alert1.get('service_name') != alert2.get('service_name'):
            return False
        
        # Same resource type
        if alert1.get('anomaly_resource_type') != alert2.get('anomaly_resource_type'):
            return False
        
        # Same severity
        if alert1.get('severity') != alert2.get('severity'):
            return False
        
        # Similar descriptions (if available)
        desc1 = alert1.get('description', '').lower()
        desc2 = alert2.get('description', '').lower()
        
        if desc1 and desc2:
            # Remove specific identifiers for comparison
            desc1_clean = self.clean_description(desc1)
            desc2_clean = self.clean_description(desc2)
            
            similarity = difflib.SequenceMatcher(None, desc1_clean, desc2_clean).ratio()
            if similarity < self.description_similarity_threshold:
                return False
        
        return True
    
    def clean_description(self, description: str) -> str:
        """Clean description for comparison by removing specific identifiers"""
        # Remove pod names, node names, IDs
        cleaned = re.sub(r'\b\w+-[a-f0-9]{8,}-\w+\b', '[POD]', description)
        cleaned = re.sub(r'\baks-\w+-\w+-\w+\b', '[NODE]', cleaned)
        cleaned = re.sub(r'\b[a-f0-9]{8,}\b', '[ID]', cleaned)
        return cleaned
    
    def consolidate_duplicate_alerts(self, duplicates: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Consolidate duplicate alerts into a single representative"""
        representative = duplicates[0].copy()
        
        # Mark as consolidated
        representative['is_duplicate'] = True
        representative['duplicate_count'] = len(duplicates)
        
        # Collect affected resources
        pods = set()
        nodes = set()
        namespaces = set()
        
        for alert in duplicates:
            if alert.get('pod'):
                pods.add(alert['pod'])
            if alert.get('node'):
                nodes.add(alert['node'])
            if alert.get('namespace'):
                namespaces.add(alert['namespace'])
        
        representative['affected_pods'] = ', '.join(list(pods)[:10])
        representative['affected_nodes'] = ', '.join(list(nodes)[:10])
        representative['affected_namespaces'] = ', '.join(list(namespaces))
        
        # Time range
        start_times = [d['start_datetime'] for d in duplicates if d.get('start_datetime')]
        if start_times:
            representative['first_occurrence'] = min(start_times)
            representative['last_occurrence'] = max(start_times)
            representative['duration_minutes'] = (max(start_times) - min(start_times)).total_seconds() / 60
        
        return representative
    
    def consolidate_alerts_by_relationships(self, alerts: List[Dict[str, Any]], graph_enricher) -> List[Dict[str, Any]]:
        """Consolidate alerts using graph relationships for RCA grouping"""
        print("Consolidating alerts by graph relationships...")
        
        consolidated_groups = []
        processed_alerts = set()
        
        for alert in alerts:
            if alert.get('_id') in processed_alerts:
                continue
            
            # Find related alerts through graph relationships
            related_alerts = graph_enricher.find_relationship_groups(alert, alerts)
            
            if len(related_alerts) > 1:
                # Create consolidated group
                consolidated_group = {
                    'group_id': len(consolidated_groups) + 1,
                    'primary_alert': alert,
                    'related_alerts': related_alerts[1:],
                    'total_alerts': len(related_alerts),
                    'relationship_type': graph_enricher.determine_group_relationship_type(related_alerts),
                    'rca_category': graph_enricher.predict_rca_category(related_alerts)
                }
                
                consolidated_groups.append(consolidated_group)
                
                # Mark as processed
                for rel_alert in related_alerts:
                    processed_alerts.add(rel_alert.get('_id'))
            else:
                # Single alert - still add for classification
                single_group = {
                    'group_id': len(consolidated_groups) + 1,
                    'primary_alert': alert,
                    'related_alerts': [],
                    'total_alerts': 1,
                    'relationship_type': 'isolated',
                    'rca_category': graph_enricher.predict_rca_category([alert])
                }
                
                consolidated_groups.append(single_group)
                processed_alerts.add(alert.get('_id'))
        
        multi_alert_groups = [g for g in consolidated_groups if g['total_alerts'] > 1]
        print(f"Created {len(consolidated_groups)} consolidated groups ({len(multi_alert_groups)} multi-alert groups)")
        
        return consolidated_groups
