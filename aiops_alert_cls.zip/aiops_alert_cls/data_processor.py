"""
Data loading and processing module for AIOps Alert Pipeline
"""

import pandas as pd
import json
import ast
from datetime import datetime
from typing import List, Dict, Any
import warnings

warnings.filterwarnings('ignore')


class DataProcessor:
    """
    Handles data loading, reshaping, and basic alert parsing
    """
    
    def __init__(self, alerts_csv_path: str, graph_json_path: str):
        self.alerts_csv_path = alerts_csv_path
        self.graph_json_path = graph_json_path
        
        # Data containers
        self.raw_alerts = []
        self.firing_alerts = []
        self.graph_relationships = []
    
    def load_and_process_alerts(self) -> List[Dict[str, Any]]:
        """Load and filter firing alerts with temporal parsing"""
        print("Loading and processing alerts...")
        
        df_raw = pd.read_csv(self.alerts_csv_path, dtype=str, on_bad_lines='skip')
        print(f"Loaded {len(df_raw)} rows")
        
        # Rename columns
        df_raw = df_raw.rename(columns={
            df_raw.columns[0]: "attribute", 
            df_raw.columns[-1]: "value"
        })
        
        print(f"Raw data columns: {list(df_raw.columns)}")
        print(f"Sample attribute values: {df_raw['attribute'].unique()}")
        
        if 'status' in df_raw.columns:
            df_raw = df_raw.rename(columns={'status': 'status_original'})
        
        id_cols = [c for c in df_raw.columns if c not in ("attribute", "value")]
        print(f"ID columns: {id_cols}")
        
        # Pivot data
        df_pivoted = df_raw.pivot_table(
            index=id_cols, 
            columns='attribute', 
            values='value', 
            aggfunc='first'
        ).reset_index()
        
        df_pivoted = df_pivoted.rename(columns={
            'labels': 'payload_metadata',
            'annotations': 'alert_description'
        })
        
        print(f"Reshaped to {len(df_pivoted)} alerts")
        print(f"Pivoted data columns: {list(df_pivoted.columns)}")
        
        # Filter to firing alerts only
        if 'status' in df_pivoted.columns:
            firing_df = df_pivoted[df_pivoted['status'].str.strip().str.lower() == 'firing']
            print(f"Found {len(firing_df)} firing alerts out of {len(df_pivoted)} total")
        else:
            firing_df = df_pivoted
        
        self.firing_alerts = firing_df.to_dict('records')
        
        print(f"Found {len(self.firing_alerts)} firing alerts")
        
        # Parse alert data
        for alert in self.firing_alerts:
            self._parse_alert_payload(alert)
            self._parse_temporal_info(alert)
        
        return self.firing_alerts
    
    def _parse_alert_payload(self, alert: Dict[str, Any]) -> None:
        """Parse payload metadata and alert description"""
        labels_str = alert.get('payload_metadata', '')
        if labels_str:
            try:
                labels = ast.literal_eval(labels_str)
                
                # Extract common fields
                alert['cluster'] = labels.get('cluster', '')
                alert['namespace'] = labels.get('namespace', '')
                alert['pod'] = labels.get('pod', '')
                alert['node'] = labels.get('node', '')
                alert['anomaly_resource_type'] = labels.get('anomaly_resource_type', '')
                alert['workload_type'] = labels.get('workload_type', '')
                alert['platform'] = labels.get('platform', '')
                alert['anomaly_entity_type'] = labels.get('anomaly_entity_type', '')
                alert['alert_category'] = labels.get('alert_category', '')
                alert['alert_subcategory'] = labels.get('alert_subcategory', '')
                alert['alertname'] = labels.get('alertname', '')
                
            except Exception as e:
                print(f"Warning: Could not parse labels for alert {alert.get('_id', 'unknown')}")
        
        # Parse annotations
        annotations_str = alert.get('alert_description', '')
        if annotations_str:
            try:
                annotations = ast.literal_eval(annotations_str)
                alert['description'] = annotations.get('description', '')
            except Exception as e:
                print(f"Warning: Could not parse annotations for alert {alert.get('_id', 'unknown')}")
        
        # Store consolidated payload
        payload_consolidated = {
            'labels': ast.literal_eval(labels_str) if labels_str else {},
            'annotations': ast.literal_eval(annotations_str) if annotations_str else {}
        }
        alert['payload_consolidated'] = str(payload_consolidated)
    
    def _parse_temporal_info(self, alert: Dict[str, Any]) -> None:
        """Parse temporal information for deduplication"""
        try:
            # Try multiple possible column names for start time
            starts_at = alert.get('startsAt') or alert.get('starts_at', '')
            if starts_at:
                alert['start_datetime'] = pd.to_datetime(starts_at)
                alert['start_timestamp'] = alert['start_datetime'].timestamp()
                alert['start_hour'] = alert['start_datetime'].hour
                alert['start_minute'] = alert['start_datetime'].minute
            else:
                # Fallback
                starts_at = alert.get('starts_at', '')
                if starts_at:
                    alert['start_datetime'] = pd.to_datetime(starts_at)
                    alert['start_timestamp'] = alert['start_datetime'].timestamp()
                    alert['start_hour'] = alert['start_datetime'].hour
                    alert['start_minute'] = alert['start_datetime'].minute
            
            # Check if ongoing (firing alerts typically have placeholder end times)
            ends_at = alert.get('endsAt') or alert.get('ends_at', '')
            alert['is_ongoing'] = ends_at in ['1-01-01 00:00:00.000', '0001-01-01T00:00:00Z', '', '2025-01-01T00:00:00Z']
            
        except Exception as e:
            print(f"Warning: Could not parse timestamps for alert {alert.get('_id', 'unknown')}")
            alert['start_datetime'] = None
            alert['start_timestamp'] = 0
            alert['is_ongoing'] = True
    
    def load_graph_data(self) -> List[Dict[str, Any]]:
        """Load graph relationship data"""
        print("Loading graph data...")
        
        with open(self.graph_json_path, 'r') as f:
            self.graph_relationships = json.load(f)
        
        print(f"Loaded {len(self.graph_relationships)} graph relationships")
        return self.graph_relationships
